﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace CrystalBallSystem.DAL.POCOs
{
    public class ProgramNameID
    {
        public int ProgramID { get; set; }
        public string ProgramName { get; set; }
    }
}
