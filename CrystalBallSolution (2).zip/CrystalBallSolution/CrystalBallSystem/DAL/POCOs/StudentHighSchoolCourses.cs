﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace CrystalBallSystem.DAL.POCOs
{
    public class StudentHighSchoolCourses
    {
        public string HighSchoolCourse { get; set; }
        public double Mark { get; set; }
    }
}
