﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace CrystalBallSystem.DAL.POCOs
{
    public class GetCredentials
    {
        public int CredentialTypeID { get; set; }
        public string CredentialTypeName { get; set; }
    }
}
