﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace CrystalBallSystem.DAL.POCOs
{
    public class GetHSCourses
    {
        public int HighSchoolCourseID { get; set; }
        public string HighSchoolCourseDescription { get; set; }
        public int CourseGroupID { get; set; }
        public int CourseLevel { get; set; }
    }
}
