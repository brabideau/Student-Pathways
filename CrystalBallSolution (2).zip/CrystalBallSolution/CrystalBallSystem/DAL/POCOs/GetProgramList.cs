﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace CrystalBallSystem.DAL.POCOs
{
    public class GetProgramList
    {
        public int EntranceRequirementID { get; set; }
        public int? RequiredMark { get; set; }
    }
}
