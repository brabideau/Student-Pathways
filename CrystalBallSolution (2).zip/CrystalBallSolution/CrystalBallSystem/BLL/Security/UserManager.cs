﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using CrystalBallSystem.DAL.Entities.Security;
using Microsoft.AspNet.Identity;
using Microsoft.AspNet.Identity.EntityFramework;
using CrystalBallSystem.DAL;

namespace CrystalBallSystem.BLL.Security
{
    public class UserManager : UserManager<ApplicationUser>
    {
        #region Constants
        private const string STR_DEFAULT_PASSWORD = "Pa$$word1";
        /// <summary>Requires FirstName and LastName</summary>
        private const string STR_USERNAME_FORMAT = "{0}";
        /// <summary>Requires UserName</summary>
        private const string STR_EMAIL_FORMAT = "{0}@nait.ca";
        private const string STR_WEBMASTER_USERNAME = "Webmaster";
        #endregion

        public UserManager()
            : base(new UserStore<ApplicationUser>(new ApplicationDbContext()))
        {
        }

        public void AddDefaultUsers()
        {
            using (var context = new CrystalBallContext())
            {
                var employees = from data in context.Administrators
   
                                select data;
                foreach (var person in employees)
                {
                    // Check if they exist
                    if (!Users.Any(u => u.AdministratorID.HasValue && u.AdministratorID.Value == person.AdministratorID))
                    {
                        string userName = string.Format(STR_USERNAME_FORMAT, person.UserName);
                        var appUser = new ApplicationUser()
                        {
                            UserName = userName,
                            Email = string.Format(STR_EMAIL_FORMAT, userName),
                            AdministratorID = person.AdministratorID
                        };
                        // NOTE: The following needs to use the this keyword in order to have access to the extension method
                        //       Create(ApplicationUser user, string password)
                        this.Create(appUser, STR_DEFAULT_PASSWORD);
                    }
                }
                // Add a web  master user
                if (!Users.Any(u => u.UserName.Equals(STR_WEBMASTER_USERNAME)))
                {
                    var webMasterAccount = new ApplicationUser()
                    {
                        UserName = STR_WEBMASTER_USERNAME,
                        Email = string.Format(STR_EMAIL_FORMAT, STR_WEBMASTER_USERNAME)
                    };
                    this.Create(webMasterAccount, STR_DEFAULT_PASSWORD);
                }
            }
        }
    }
}
